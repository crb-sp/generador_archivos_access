#main.y
import os
from dotenv import load_dotenv
from modulos.conexion import conectar_base_datos
from modulos.generar_access import generar_archivos

# Cargar variables de entorno
load_dotenv()

# Directorio de salida
output_dir = os.getenv('OUTPUT_DIR', 'output_sqlite_files')
os.makedirs(output_dir, exist_ok=True)

if __name__ == "__main__":
    conexion = conectar_base_datos()
    if not conexion:
        print("Error al conectar a la base de datos. Verifica las configuraciones.")
        exit(1)

    # Lógica principal
    generar_archivos(conexion, output_dir)
    conexion.close()
