import pandas as pd
import random

def generar_numero_unico(codigo_area):
    """Genera un número único concatenando el código de área con un número aleatorio."""
    numero = random.randint(100000, 999999)
    return f"{codigo_area}{numero}"

def procesar_excel(ruta_archivo):
    try:
        # Leer archivo Excel
        columnas = pd.read_excel(ruta_archivo, usecols=["LOCALIDAD", "INDICATIVO"])
        columnas = columnas.dropna()

        # Generar números de teléfono únicos
        columnas['TELEFONO'] = columnas['INDICATIVO'].apply(generar_numero_unico)

        # Convertir a lista de tuplas
        return list(columnas.itertuples(index=False, name=None))
    except Exception as e:
        print(f"Error al procesar el archivo Excel {ruta_archivo}: {e}")
        return []
