# Consultas SELECT
SELECT_LOCALIDADES = """
SELECT DISTINCT localidad
FROM numeros
"""

SELECT_TELEFONOS_POR_LOCALIDAD = """
SELECT localidad, numero AS telefono
FROM numeros
WHERE localidad = %s
LIMIT %s
"""

# Consultas INSERT
INSERT_NUMEROS = """
INSERT INTO numeros (localidad, numero)
VALUES (%s, %s)
ON DUPLICATE KEY UPDATE numero = VALUES(numero)
"""
