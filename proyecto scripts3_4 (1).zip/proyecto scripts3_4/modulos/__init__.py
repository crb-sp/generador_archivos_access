from .conexion import conectar_base_datos, insertar_datos
from .procesar_excel import procesar_excel
from .sqlite_utils import crear_archivo
from .generar_access import generar_archivos
from .queries import SELECT_LOCALIDADES, SELECT_TELEFONOS_POR_LOCALIDAD
