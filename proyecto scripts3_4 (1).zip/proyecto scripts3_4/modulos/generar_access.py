import os
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

MAX_ARCHIVOS = int(os.getenv("MAX_ARCHIVOS", 10))
LIMITE_REGISTROS = int(os.getenv("LIMITE_REGISTROS", 7000))

def generar_archivos(conexion, salida, max_archivos=MAX_ARCHIVOS, limite_registros=LIMITE_REGISTROS):
    # Importar SELECT_LOCALIDADES y SELECT_TELEFONOS_POR_LOCALIDAD dentro de la función
    from modulos import SELECT_LOCALIDADES, SELECT_TELEFONOS_POR_LOCALIDAD, crear_archivo

    cursor = conexion.cursor(dictionary=True)

    # Obtener localidades
    cursor.execute(SELECT_LOCALIDADES)
    localidades = [loc['localidad'] for loc in cursor.fetchall()]

    if not localidades:
        print("No hay localidades en la tabla numeros.")
        return

    for idx, localidad in enumerate(localidades):
        if idx >= max_archivos:
            break

        # Consultar datos de la localidad
        cursor.execute(SELECT_TELEFONOS_POR_LOCALIDAD, (localidad, limite_registros))
        telefonos = pd.DataFrame(cursor.fetchall())

        if telefonos.empty:
            print(f"No hay números para la localidad {localidad}.")
            continue

        ruta_archivo = os.path.join(salida, f"campania_{idx + 1}.sqlite")
        print(f"Creando archivo para localidad '{localidad}' en: {ruta_archivo}")
        crear_archivo(telefonos, ruta_archivo)

    cursor.close()
