import pyodbc
import pandas as pd
import os
from dotenv import load_dotenv

# Cargar las variables desde el archivo .env
load_dotenv()

# Función para cargar la configuración de tablas desde el archivo .env
def cargar_configuracion():
    try:
        nombre_tabla = os.getenv('NOMBRE_TABLA')
        columnas = os.getenv('COLUMNAS')

        if not nombre_tabla or not columnas:
            raise ValueError("Faltan configuraciones en el archivo .env")

        # Convertir las columnas en una lista
        columnas = columnas.split(',')
        return {'nombre_tabla': nombre_tabla, 'columnas': columnas}
    except Exception as e:
        print(f"Error al cargar la configuración desde .env: {e}")
        return None

# Función para crear o conectar a un archivo Access
def conectar_access(ruta_archivo):
    if not ruta_archivo.endswith('.mdb'):
        ruta_archivo += '.mdb'

    # Crear el archivo si no existe
    if not os.path.exists(ruta_archivo):
        connection_string = (
            f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};"
            f"DBQ={ruta_archivo};"
        )
        with pyodbc.connect(connection_string, autocommit=True) as conn:
            print(f"Archivo Access creado en {ruta_archivo}.")

    # Conectarse al archivo Access
    connection_string = (
        f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};"
        f"DBQ={ruta_archivo};"
    )
    return pyodbc.connect(connection_string)

# Función para crear una tabla en Access
def crear_tabla_access(conn, nombre_tabla, columnas):
    try:
        cursor = conn.cursor()

        # Crear tabla si no existe
        columnas_definicion = ", ".join([f"{col} TEXT" for col in columnas])
        cursor.execute(f"""
            CREATE TABLE {nombre_tabla} (
                {columnas_definicion}
            )
        """)
        print(f"Tabla '{nombre_tabla}' creada con columnas: {', '.join(columnas)}.")
    except Exception as e:
        if "already exists" in str(e):
            print(f"La tabla '{nombre_tabla}' ya existe.")
        else:
            print(f"Error al crear la tabla '{nombre_tabla}': {e}")

# Función para insertar datos en una tabla de Access
def insertar_datos_access(conn, nombre_tabla, datos):
    try:
        cursor = conn.cursor()

        # Generar la consulta de inserción dinámica
        columnas = datos.columns.tolist()
        placeholders = ", ".join(["?"] * len(columnas))
        query = f"INSERT INTO {nombre_tabla} ({', '.join(columnas)}) VALUES ({placeholders})"

        # Insertar los datos
        for _, fila in datos.iterrows():
            cursor.execute(query, tuple(fila))

        # Confirmar cambios
        conn.commit()
        print(f"Datos insertados exitosamente en la tabla '{nombre_tabla}'.")
    except Exception as e:
        print(f"Error al insertar datos en la tabla '{nombre_tabla}': {e}")

# Función principal para crear archivo Access y manejar datos
def crear_archivo(datos, ruta_archivo):
    try:
        # Cargar configuración de la tabla desde .env
        configuracion = cargar_configuracion()
        if not configuracion:
            return

        nombre_tabla = configuracion.get('nombre_tabla')
        columnas = configuracion.get('columnas')

        if not nombre_tabla or not columnas:
            print("La configuración no incluye el nombre de la tabla o las columnas.")
            return

        # Conectar al archivo Access
        conn = conectar_access(ruta_archivo)

        # Crear la tabla
        crear_tabla_access(conn, nombre_tabla, columnas)

        # Verificar que las columnas del DataFrame coincidan con la configuración
        if not all(col in datos.columns for col in columnas):
            print("Las columnas del DataFrame no coinciden con la configuración.")
            return

        # Insertar los datos
        insertar_datos_access(conn, nombre_tabla, datos)

        conn.close()
        print(f"Archivo Access creado exitosamente en {ruta_archivo}.")
    except Exception as e:
        print(f"Error al generar el archivo Access en {ruta_archivo}: {e}")
