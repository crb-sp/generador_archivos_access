import os
from dotenv import load_dotenv
from mysql.connector import connect, Error
from modulos.queries import INSERT_NUMEROS

load_dotenv()

def conectar_base_datos():
    try:
        conexion = connect(
            host=os.getenv("DB_HOST"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            database=os.getenv("DB_NAME"),
            port=int(os.getenv("DB_PORT", 3306))
        )
        if conexion.is_connected():
            print("Conexión exitosa a la base de datos.")
            return conexion
    except Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None

def insertar_datos(conexion, datos):
    """
    Inserta datos en la tabla 'numeros'.
    """
    try:
        cursor = conexion.cursor()
        cursor.executemany(INSERT_NUMEROS, datos)
        conexion.commit()
        cursor.close()
    except Error as e:
        print(f"Error al insertar datos: {e}")
