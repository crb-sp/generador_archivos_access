import pandas as pd
import os
from dotenv import load_dotenv
import mysql.connector

# Cargar variables de entorno desde el archivo .env
load_dotenv()

def cargar_localidades(ruta_archivo):
    try:
        # Leer el archivo Excel y seleccionar solo la columna LOCALIDAD
        columnas = pd.read_excel(ruta_archivo, header=0)
        localidades = columnas["LOCALIDAD"].dropna().unique()  # Eliminar nulos y duplicados

        # Ordenar las localidades alfabéticamente
        localidades_ordenadas = sorted(localidades)

        # Crear los datos para insertar en la base de datos (solo localidad)
        return [(localidad,) for localidad in localidades_ordenadas]
    except Exception as e:
        print("Error al procesar el archivo Excel:", e)
        return []

def guardar_en_base_de_datos(datos):
    try:
        # Obtener credenciales de la base de datos desde las variables de entorno
        db_host = os.getenv('DB_HOST', 'localhost') # si el primer argumento no funciona, se usa el segundo
        db_port = os.getenv('DB_PORT', '3306')
        db_user = os.getenv('DB_USER', 'root')
        db_password = os.getenv('DB_PASSWORD', '')
        db_name = os.getenv('DB_NAME', 'test')

        # Conexión a la base de datos MySQL
        conexion = mysql.connector.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password,
            database=db_name
        )

        cursor = conexion.cursor()

        # Insertar las localidades en la base de datos
        for localidad in datos:
            query = "INSERT INTO localidades (ciudad) VALUES (%s)" # poner el nombre de la tabla y de la columna que corresponda
            cursor.execute(query, localidad)

        # Confirmar los cambios en la base de datos
        conexion.commit()
        print(f"{cursor.rowcount} registros insertados correctamente.")

        cursor.close()
        conexion.close()

    except mysql.connector.Error as err:
        print(f"Error al conectar a la base de datos: {err}")

if __name__ == "__main__":

    # Obtener la ruta del archivo Excel desde la variable de entorno, con valor por defecto
    ruta_archivo = os.getenv(
        "EXCEL_PATH_LOCALIDADES",
        "/home/cristian/Documentos/Unsada/Informatica_2024/Laboratorio_de_lenguajes_2024/semana9_HTML+PHP_y_TPI_final/localidades.xls"
    )

    if not ruta_archivo:
        print("Error: No se ha especificado la ruta del archivo en el archivo .env")
    else:
        # Cargar los datos desde el archivo Excel
        datos = cargar_localidades(ruta_archivo)

        # Si hay datos, guardarlos en la base de datos
        if datos:
            guardar_en_base_de_datos(datos)
        else:
            print("No se encontraron datos para insertar.")
